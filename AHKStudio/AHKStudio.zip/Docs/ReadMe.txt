https://autohotkey.com/boards/viewtopic.php?f=6&t=300
