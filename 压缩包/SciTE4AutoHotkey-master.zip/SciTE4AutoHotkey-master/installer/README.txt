SciTE4AutoHotkey Setup Source Code
----------------------------------

The Setup program is packaged as a 7-zip "for installers" self-extracting executable
which contains a bundled archive with the following contents:

- InternalAHK.exe
- $SETUP (single-file preprocessed version of setup.ahk)
- dialog.html
- banner.png
- $DATA\ (contains the SciTE4AutoHotkey program files)
